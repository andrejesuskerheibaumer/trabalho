from django.contrib import admin
from nyapp.models import Pessoa , Historia

# Register your models here.

admin.site.register(Pessoa)

admin.site.register(Historia)