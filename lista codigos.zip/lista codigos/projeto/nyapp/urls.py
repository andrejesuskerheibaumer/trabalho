from django.contrib import admin
from django.urls import path, include
from .views import home , cadastro, login ,lobby,publicar, leitura, secret_login , perfil
from . import views

urlpatterns = [
    path('', cadastro, name='cadastro'),
    path('login/', login, name='login'),
    path('lobby/', lobby, name='lobby'),
    path('publicar/', publicar, name='publicar'),
    path('leitura/', leitura, name='leitura'),
    path('perfil/<str:hnome>/',perfil, name='perfil'),


    # Rota para a lista de histórias
    path('leitura/', leitura, name='leitura'),
    
    # Rota para ler uma história específica, usando o ID dela
    path('leitura/<int:historia_id>/', leitura, name='ler_historia'),


    
    path('crud/', views.crud_view, name='crud'),
    path('delete_pessoa/<int:pk>/', views.delete_pessoa, name='delete_pessoa'),
    path('delete_historia/<int:pk>/', views.delete_historia, name='delete_historia'),
    path('secret_login/', secret_login, name='secret_login'),
]